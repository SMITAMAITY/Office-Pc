// function f2(){
    let p =
new Promise(function(resolve,reject){
        setTimeout( ()=> {
            const error = false;

            if(error){
                // console.log();
                resolve('Your Request is resolved');
            }
            else{
                // console.log('Sorry!!! Your Request is not resolved');
                reject('Failure');
            }
        }, 2000);
        })

   


    p.then(function(message){
        console.log('Smita: Thanks for resolving ' + message);
    }).catch(function(message){
        console.log('Cannot be resolved. So it is a ' + message );
    })

