function f(){
return new Promise(function(resolve,reject) {
    let s = 1 + 1
    if(s == 2)
    {
        console.log('Your request is resolved');
        resolve('Success');
        
    }
    else{
        console.log('Your request is not resolved');
        reject('Failed');
    }

})
}
f().then(function(){
    console.log('This is in the then ' );
}).catch(function(){
    console.log('This is in the catch ' );
}) 