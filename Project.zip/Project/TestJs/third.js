 var t1=function(){
     console.log('smita')

 }
for (var i=1;i<=5;i++)
{
    var tag = document.getElementById('app'+i);
    // tag.onclick = function(){
         console.log(i)
    // }
    
}
