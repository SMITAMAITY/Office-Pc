let firstname = 'Smita';
let lastname = 'Maity';

console.log(firstname);
console.log(lastname);

let details = 'FullName : ' + firstname + ' '+ lastname;
console.log(details)