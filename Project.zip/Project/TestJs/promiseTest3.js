const VideoRecordedOne = new Promise((resolve,reject)=>{
    resolve('Video One is Recorded')
})

const VideoRecordedTwo = new Promise((resolve,reject)=>{
    resolve('Video Two is Recorded')
})

const VideoRecordedThree = new Promise((resolve,reject)=>{
    resolve('Video Three is Recorded')
})

// Promise.all([
//     VideoRecordedOne,
//     VideoRecordedTwo,
//     VideoRecordedThree
// ]).then((messages) => {
//     console.log(messages)
// })

   Promise.race([
    VideoRecordedOne,
    VideoRecordedTwo,
    VideoRecordedThree
]).then((message) => {
    console.log(message)
})