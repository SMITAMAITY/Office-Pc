import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-setting-landing-page',
  templateUrl: './setting-landing-page.component.html',
  styleUrls: ['./setting-landing-page.component.css']
})
export class SettingLandingPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
