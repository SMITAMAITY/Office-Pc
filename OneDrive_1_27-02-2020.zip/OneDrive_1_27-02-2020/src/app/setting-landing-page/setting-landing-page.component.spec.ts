import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SettingLandingPageComponent } from './setting-landing-page.component';

describe('SettingLandingPageComponent', () => {
  let component: SettingLandingPageComponent;
  let fixture: ComponentFixture<SettingLandingPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SettingLandingPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SettingLandingPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
