import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-passenger-login',
  templateUrl: './passenger-login.component.html',
  styleUrls: ['./passenger-login.component.css']
})
export class PassengerLoginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
