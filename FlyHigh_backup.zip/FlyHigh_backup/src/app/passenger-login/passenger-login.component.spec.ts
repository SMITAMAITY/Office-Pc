import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PassengerLoginComponent } from './passenger-login.component';

describe('PassengerLoginComponent', () => {
  let component: PassengerLoginComponent;
  let fixture: ComponentFixture<PassengerLoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PassengerLoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PassengerLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
