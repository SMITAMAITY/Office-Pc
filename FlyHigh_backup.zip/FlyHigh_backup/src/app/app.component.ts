import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'FlyHigh';
}

for (var i=1;i<=5;i++)
        {
            var tag = document.getElementById('app'+i);
            tag.onclick = function(){
         console.log(i)
        }
        }
      